function addToCart(productName) {
    alert(`${productName} has been added to your cart!`);
}
